<html>

<body>

<table>

<tr>

<form method=post action=bank.php>

<th>

<input type=text name=acc placeholder='Enter Account no'>
</th>

</tr>

<tr><th><input type=text name=pin placeholder='Enter pin code'></th></tr>

<tr><th>

<?php
	
if(isset($btn)) 

{

a();

}
?>
</th></tr>

<tr><th></th></tr>

<tr><th><input type=submit name=btn value=Enter></th></tr>

</form>

</table>
</body>
</html>