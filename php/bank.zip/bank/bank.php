<?php
$acc1=123456;

$bal1=3000;

$pin1=1234;


extract($_POST);
if($acc1==$acc && $pin1==$pin)
{
echo "<a><button>next</button></a>";
}
else if($acc1!=$acc && $pin1!=$pin)
{
echo "Please Enter valid Acc no and Pin";
}
else if($acc!=$acc1)
{
echo "Enter valid Acc";
}
else if($pin1!=$pin)
{
echo "Enter valid Pin";
}

 
?>
